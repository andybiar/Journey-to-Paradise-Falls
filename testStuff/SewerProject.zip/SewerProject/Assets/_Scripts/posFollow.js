var mycontroller : Transform;

function Update () 
{
	transform.position.x = mycontroller.position.x;
	transform.position.z = mycontroller.position.z;
}
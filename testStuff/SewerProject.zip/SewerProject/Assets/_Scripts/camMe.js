
@script ExecuteInEditMode

function Update () {
    camera.depthTextureMode = DepthTextureMode.Depth;
}